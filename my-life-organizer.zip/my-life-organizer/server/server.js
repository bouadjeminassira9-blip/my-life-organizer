'use strict';
/**
 * خادم صغير لتطبيق منظم حياتي:
 *  1) يقدّم ملفات التطبيق من مجلد ../public (يمكنك نشر التطبيق والخادم معاً).
 *  2) يرسل إشعارات Web Push حقيقية في مواعيد تذكيراتك حتى والتطبيق مغلق.
 *
 * متغيرات البيئة:
 *   VAPID_PUBLIC_KEY / VAPID_PRIVATE_KEY  (انظري README: npm run keys)
 *   VAPID_SUBJECT   مثال: mailto:you@example.com
 *   DATA_DIR        مجلد حفظ الاشتراكات (الافتراضي ./data)
 *   TICK_SECRET     (اختياري) سرّ لحماية /api/tick
 */
const http = require('http'), fs = require('fs'), path = require('path');
const webpush = require('web-push');

const PORT = process.env.PORT || 3000;
const PUB = path.join(__dirname, '..', 'public');
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'subs.json');
fs.mkdirSync(DATA_DIR, { recursive: true });

let keys = { publicKey: process.env.VAPID_PUBLIC_KEY, privateKey: process.env.VAPID_PRIVATE_KEY };
const KEYS_FILE = path.join(DATA_DIR, 'vapid.json');
if (!keys.publicKey || !keys.privateKey) {
  if (fs.existsSync(KEYS_FILE)) keys = JSON.parse(fs.readFileSync(KEYS_FILE, 'utf8'));
  else { keys = webpush.generateVAPIDKeys(); fs.writeFileSync(KEYS_FILE, JSON.stringify(keys)); console.log('تم توليد مفاتيح VAPID جديدة وحفظها. على الاستضافات المؤقتة ضعيها في متغيرات البيئة.'); }
}
webpush.setVapidDetails(process.env.VAPID_SUBJECT || 'mailto:admin@example.com', keys.publicKey, keys.privateKey);

let subs = {}; // endpoint -> { subscription, tz, reminders, sent: {id: 'YYYY-MM-DD'} }
try { subs = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); } catch { }
const save = () => fs.writeFile(DB_FILE, JSON.stringify(subs), () => { });

function localNow(tz) {
  try {
    const p = Object.fromEntries(new Intl.DateTimeFormat('en-CA', { timeZone: tz, hour12: false, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }).formatToParts(new Date()).map(x => [x.type, x.value]));
    return { date: `${p.year}-${p.month}-${p.day}`, min: (+p.hour % 24) * 60 + +p.minute };
  } catch { const d = new Date(); return { date: d.toISOString().slice(0, 10), min: d.getUTCHours() * 60 + d.getUTCMinutes() }; }
}

async function tick() {
  let sent = 0, dirty = false;
  for (const [ep, s] of Object.entries(subs)) {
    const now = localNow(s.tz || 'UTC'); s.sent = s.sent || {};
    for (const r of s.reminders || []) {
      if (!r.on || !/^\d\d:\d\d$/.test(r.time)) continue;
      const [h, m] = r.time.split(':').map(Number), diff = now.min - (h * 60 + m);
      if (diff >= 0 && diff <= 90 && s.sent[r.id] !== now.date) {
        try {
          await webpush.sendNotification(s.subscription, JSON.stringify({ title: 'منظم حياتي 🌷', body: r.body, tag: r.id + '-' + now.date, url: './index.html#/tasks' }));
          s.sent[r.id] = now.date; sent++; dirty = true;
        } catch (e) {
          if (e.statusCode === 404 || e.statusCode === 410) { delete subs[ep]; dirty = true; break; }
          console.error('push error', e.statusCode || e.message);
        }
      }
    }
  }
  if (dirty) save();
  return sent;
}
setInterval(() => tick().catch(console.error), 30 * 1000);

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.svg': 'image/svg+xml' };
const readBody = req => new Promise(res => { let b = ''; req.on('data', c => { b += c; if (b.length > 1e6) req.destroy(); }); req.on('end', () => { try { res(JSON.parse(b || '{}')); } catch { res({}); } }); });
const json = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }); res.end(JSON.stringify(obj)); };

http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  if (req.method === 'OPTIONS') { res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Allow-Methods': 'GET,POST,OPTIONS' }); return res.end(); }
  if (url.pathname === '/api/health') return json(res, 200, { ok: true, subs: Object.keys(subs).length });
  if (url.pathname === '/api/vapid') return json(res, 200, { key: keys.publicKey });
  if (url.pathname === '/api/tick') { if (process.env.TICK_SECRET && url.searchParams.get('s') !== process.env.TICK_SECRET) return json(res, 403, { ok: false }); return json(res, 200, { ok: true, sent: await tick() }); }
  if (req.method === 'POST' && url.pathname === '/api/sync') {
    const b = await readBody(req); if (!b.subscription || !b.subscription.endpoint) return json(res, 400, { ok: false });
    const old = subs[b.subscription.endpoint] || {};
    subs[b.subscription.endpoint] = { subscription: b.subscription, tz: b.tz || 'UTC', reminders: (b.reminders || []).slice(0, 30), sent: old.sent || {} };
    save(); return json(res, 200, { ok: true });
  }
  if (req.method === 'POST' && url.pathname === '/api/unsubscribe') { const b = await readBody(req); delete subs[b.endpoint]; save(); return json(res, 200, { ok: true }); }
  if (req.method === 'POST' && url.pathname === '/api/test') {
    const b = await readBody(req), s = subs[b.endpoint]; if (!s) return json(res, 404, { ok: false });
    try { await webpush.sendNotification(s.subscription, JSON.stringify({ title: 'منظم حياتي 🌷', body: 'إشعار تجريبي من الخادم: يعمل والتطبيق مغلق ✅', tag: 'test' })); return json(res, 200, { ok: true }); }
    catch (e) { return json(res, 500, { ok: false, error: String(e.statusCode || e.message) }); }
  }
  // ملفات التطبيق
  let p = decodeURIComponent(url.pathname); if (p === '/') p = '/index.html';
  const file = path.normalize(path.join(PUB, p));
  if (!file.startsWith(PUB)) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    const h = { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' };
    if (p === '/sw.js') h['Cache-Control'] = 'no-cache';
    res.writeHead(200, h); res.end(data);
  });
}).listen(PORT, () => console.log('منظم حياتي يعمل على المنفذ', PORT));
