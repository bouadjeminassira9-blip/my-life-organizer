'use strict';
/* ============ أدوات عامة ============ */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pad = n => String(n).padStart(2, '0');
const keyOf = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const parseKey = k => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d); };
const todayKey = () => keyOf(new Date());
const addDays = (k, n) => { const d = parseKey(k); d.setDate(d.getDate() + n); return keyOf(d); };
const uid = () => Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-4);
const DAYS = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
const DAYS_SHORT = ['أحد', 'اثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'];
const MONTHS = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));

/* ============ قاعدة البيانات: IndexedDB مع ذاكرة مؤقتة ============ */
const DB = (() => {
  const NAME = 'life-organizer', STORE = 'kv';
  let db = null, cache = {};
  const openDB = () => new Promise((res, rej) => {
    const r = indexedDB.open(NAME, 1);
    r.onupgradeneeded = () => r.result.createObjectStore(STORE);
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
  async function load() {
    try {
      db = await openDB();
      await new Promise((res, rej) => {
        const cur = db.transaction(STORE).objectStore(STORE).openCursor();
        cur.onsuccess = e => { const c = e.target.result; if (c) { cache[c.key] = c.value; c.continue(); } else res(); };
        cur.onerror = () => rej(cur.error);
      });
    } catch (e) { // وضع احتياطي: localStorage
      db = null;
      for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k.startsWith('lo:')) { try { cache[k.slice(3)] = JSON.parse(localStorage.getItem(k)); } catch { } } }
    }
    try { navigator.storage && navigator.storage.persist && navigator.storage.persist(); } catch { }
  }
  const get = (k, d) => (k in cache ? cache[k] : d);
  function set(k, v) {
    cache[k] = v;
    if (!db) { try { localStorage.setItem('lo:' + k, JSON.stringify(v)); } catch { } return Promise.resolve(); }
    return new Promise(res => { const tx = db.transaction(STORE, 'readwrite'); tx.objectStore(STORE).put(v, k); tx.oncomplete = res; tx.onerror = res; });
  }
  function del(k) {
    delete cache[k];
    if (!db) { localStorage.removeItem('lo:' + k); return Promise.resolve(); }
    return new Promise(res => { const tx = db.transaction(STORE, 'readwrite'); tx.objectStore(STORE).delete(k); tx.oncomplete = res; tx.onerror = res; });
  }
  function getFresh(k) {
    if (!db) return Promise.resolve(get(k));
    return new Promise(res => { const r = db.transaction(STORE).objectStore(STORE).get(k); r.onsuccess = () => res(r.result); r.onerror = () => res(undefined); });
  }
  const keys = (prefix = '') => Object.keys(cache).filter(k => k.startsWith(prefix));
  async function clearAll() {
    cache = {};
    if (!db) { Object.keys(localStorage).filter(k => k.startsWith('lo:')).forEach(k => localStorage.removeItem(k)); return; }
    await new Promise(res => { const tx = db.transaction(STORE, 'readwrite'); tx.objectStore(STORE).clear(); tx.oncomplete = res; tx.onerror = res; });
  }
  const dump = () => JSON.parse(JSON.stringify(cache));
  return { load, get, set, del, getFresh, keys, clearAll, dump };
})();

/* ============ البيانات الافتراضية ============ */
const CATS = [
  { id: 'worship', name: 'العبادة', ic: '🕌' },
  { id: 'english', name: 'الإنجليزية', ic: '🔤' },
  { id: 'health', name: 'الرياضة والصحة', ic: '🏃‍♀️' },
  { id: 'home', name: 'المنزل', ic: '🏡' },
  { id: 'care', name: 'العناية الشخصية', ic: '🧴' },
  { id: 'family', name: 'الأمومة والعائلة', ic: '🧸' },
  { id: 'work', name: 'التطوير المهني', ic: '🔬' },
];
const catOf = id => CATS.find(c => c.id === id) || CATS[0];
const ALLD = [0, 1, 2, 3, 4, 5, 6];

function defaultTasks() {
  const T = (id, cat, name, o = {}) => ({ id, cat, name, points: 10, days: ALLD, star: false, time: '', auto: '', slot: '', ...o });
  return [
    T('w_fajr', 'worship', 'صلاة الفجر', { time: '05:30' }), T('w_dhuhr', 'worship', 'صلاة الظهر'), T('w_asr', 'worship', 'صلاة العصر'),
    T('w_maghrib', 'worship', 'صلاة المغرب'), T('w_isha', 'worship', 'صلاة العشاء'),
    T('w_am', 'worship', 'أذكار الصباح', { points: 5 }), T('w_pm', 'worship', 'أذكار المساء', { points: 5 }),
    T('w_quran', 'worship', 'ورد القرآن الكريم', { star: true, points: 15 }),
    T('w_istighfar', 'worship', 'الاستغفار', { points: 5 }), T('w_dua', 'worship', 'الدعاء', { points: 5 }),
    T('e_words', 'english', 'حفظ 5 كلمات جديدة', { star: true, auto: 'words' }),
    T('e_listen', 'english', 'الاستماع (10 دقائق)'), T('e_read', 'english', 'القراءة (10 دقائق)'),
    T('e_speak', 'english', 'المحادثة (5 دقائق)'), T('e_grammar', 'english', 'القواعد والمراجعة', { days: [6, 0, 1, 2, 3, 4] }),
    T('h_walk', 'health', 'المشي'), T('h_ex', 'health', 'التمارين الرياضية', { days: [0, 1, 3, 4, 6], points: 15 }),
    T('h_water', 'health', 'شرب الماء (الهدف)', { auto: 'water' }), T('h_food', 'health', 'تغذية متوازنة'), T('h_sleep', 'health', 'نوم كافٍ'),
    T('m_tidy', 'home', 'ترتيب المنزل', { points: 8 }), T('m_kitchen', 'home', 'ترتيب المطبخ', { points: 8 }),
    T('m_laundry', 'home', 'الغسيل', { days: [6, 1, 3], points: 8 }),
    T('m_bed', 'home', 'تنظيف غرفة النوم', { days: [6], points: 8 }), T('m_living', 'home', 'تنظيف غرفة المعيشة', { days: [0], points: 8 }),
    T('m_bath', 'home', 'تنظيف الحمام', { days: [1], points: 8 }), T('m_kid', 'home', 'تنظيف غرفة الطفل', { days: [2], points: 8 }),
    T('m_deep', 'home', 'تنظيف المطبخ بعمق', { days: [3], points: 8 }),
    T('m_weekly', 'home', 'التنظيم الأسبوعي (قائمة المشتريات وبرنامج الأسبوع)', { days: [4], points: 12 }),
    T('c_am', 'care', 'روتين البشرة الصباحي', { slot: 'am', points: 5 }), T('c_spf', 'care', 'واقي الشمس', { slot: 'am', points: 5 }),
    T('c_pm', 'care', 'روتين البشرة المسائي', { slot: 'pm', points: 5 }), T('c_hair', 'care', 'العناية بالشعر والجسم', { days: [3, 6], points: 8 }),
    T('f_play', 'family', 'وقت اللعب مع ابني', { star: true, points: 15 }), T('f_needs', 'family', 'الاهتمام باحتياجات ابني'),
    T('f_act', 'family', 'نشاط مناسب لعمر ابني', { days: [6, 1, 3] }), T('f_time', 'family', 'وقت عائلي', { days: [4, 5, 6], points: 12 }),
    T('p_lessons', 'work', 'تحضير الدروس', { days: [6, 0, 1, 2, 3], points: 12 }), T('p_ex', 'work', 'تحضير التمارين', { days: [0, 2], points: 10 }),
    T('p_method', 'work', 'تطوير منهجية العلوم الطبيعية', { days: [3], points: 12 }), T('p_eng', 'work', 'تطوير الإنجليزية العلمية', { days: [1, 4], points: 10 }),
  ];
}
const defaultSettings = () => ({ name: '', theme: 'auto', weekStart: 6, waterGoal: 8, engGoal: 30, sportGoal: 3, engTargetHours: 150, server: '' });
const defaultReminders = () => [
  { id: 'morning', label: 'تذكير الصباح', time: '07:00', on: false, body: 'صباح الخير 🌷 افتحي منظم حياتي وابدئي يومك بهدوء.' },
  { id: 'midday', label: 'مراجعة منتصف اليوم', time: '13:30', on: false, body: 'استراحة قصيرة 🌿 راجعي مهامك، وما أنجزتِه يكفي.' },
  { id: 'evening', label: 'تقييم المساء', time: '21:00', on: false, body: 'مساء الخير 🌙 سجّلي إنجازات اليوم وراجعيها بلطف.' },
  { id: 'english', label: 'تذكير الإنجليزية', time: '17:30', on: false, body: 'وقت الإنجليزية 📖 نصف ساعة تقرّبك من B2.' },
  { id: 'sport', label: 'تذكير الرياضة', time: '18:30', on: false, body: 'حركة خفيفة اليوم 🚶‍♀️ ولو عشر دقائق تكفي.' },
  { id: 'skin', label: 'العناية بالبشرة مساءً', time: '22:00', on: false, body: 'روتين البشرة المسائي ✨ دقائق لنفسك.' },
];
const defaultPlan = () => ({ 0: 'مشي سريع 30 دقيقة', 1: 'تمارين قوة بوزن الجسم 20 دقيقة', 2: 'راحة أو تمدد خفيف', 3: 'مشي 30 دقيقة', 4: 'كارديو خفيف مع ابني 20 دقيقة', 5: 'نشاط عائلي في الهواء الطلق', 6: 'يوغا وتمدد 15 دقيقة' });
const defaultProducts = () => [
  { id: 'p1', name: 'غسول الوجه', slot: 'both' }, { id: 'p2', name: 'تونر', slot: 'both' }, { id: 'p3', name: 'سيروم', slot: 'am' },
  { id: 'p4', name: 'مرطب', slot: 'both' }, { id: 'p5', name: 'واقي الشمس', slot: 'am' }, { id: 'p6', name: 'كريم ليلي', slot: 'pm' },
];
const MEALS = { breakfast: 'الفطور', lunch: 'الغداء', dinner: 'العشاء', snacks: 'وجبات خفيفة' };
const SUGGEST = {
  breakfast: ['بيض مسلوق + خبز كامل + خيار وطماطم', 'زبادي + شوفان + تمر وجوز', 'فول أو حمص + خبز أسمر + زيت زيتون', 'سموذي موز وحليب وشوفان'],
  lunch: ['دجاج مشوي + أرز أسمر + سلطة خضراء', 'سمك مشوي + بطاطا مطبوخة + خضار', 'عدس أو شوربة خضار + خبز كامل + سلطة', 'كسكسي بالخضار والحمص'],
  dinner: ['شوربة خفيفة + تونة وخضار', 'أومليت خضار + سلطة', 'زبادي + فاكهة + حفنة لوز', 'بطاطا حلوة مشوية + جبن قليل الدسم'],
  snacks: ['تفاحة + لوز', 'موزة + زبادي', 'حمص مع جزر وخيار', 'تمرتان + كوب حليب'],
};
const SKILLS = { listening: 'استماع', reading: 'قراءة', speaking: 'محادثة', grammar: 'قواعد', vocab: 'مفردات' };
const SKILL_IDEAS = {
  listening: ['بودكاست قصير بالإنجليزية (6 دقائق) مع قراءة النص بعد الاستماع', 'فيديو علمي مبسط مع ترجمة إنجليزية'],
  reading: ['مقال قصير في العلوم أو الصحة، وتدوين 5 كلمات منه', 'قصة مبسطة بمستوى B1–B2'],
  speaking: ['سجّلي صوتك دقيقة تصفين فيها يومك', 'اشرحي درساً علمياً بسيطاً بالإنجليزية بصوت عالٍ'],
  grammar: ['درس قواعد واحد + 5 جمل من تأليفك', 'مراجعة الأزمنة: الماضي البسيط/التام والمستقبل'],
};
const MOTIV = {
  morning: ['صباح الخير 🌷 خطوة صغيرة اليوم تكفي لتبدأ يوماً جميلاً.', 'يوم جديد وفرصة هادئة لتفعلي ما تحبين. بسم الله 🌿', 'لا تحتاجين يوماً مثالياً، يكفي يوم حاضر بقلبك ✨'],
  noon: ['منتصف اليوم ☀️ خذي نفساً، وراجعي ما أنجزتِه بامتنان.', 'ما أنجزتِه حتى الآن يستحق الفخر 🌸 والباقي بخفة.', 'اشربي ماءً، وارتاحي دقيقة، ثم أكملي بهدوئك 💧'],
  evening: ['مساء الخير 🌙 أنتِ تفعلين الكثير، وهذا يكفي.', 'راجعي يومك بلطف؛ كل خطوة تُحسب 🌷', 'ما لم يكتمل اليوم ينتظرك غداً بلا حرج 🤍'],
};
const LEVELS = [
  { at: 0, n: 'بذرة', e: '🌱' }, { at: 150, n: 'برعم', e: '🌿' }, { at: 400, n: 'زهرة', e: '🌷' }, { at: 800, n: 'باقة', e: '💐' },
  { at: 1400, n: 'بستان', e: '🌳' }, { at: 2200, n: 'واحة', e: '🌴' }, { at: 3200, n: 'نجمة', e: '✨' }, { at: 4500, n: 'ملكة التوازن', e: '👑' },
];

async function seed() {
  if (!DB.get('tasks')) await DB.set('tasks', defaultTasks());
  if (!DB.get('settings')) await DB.set('settings', defaultSettings());
  if (!DB.get('reminders')) await DB.set('reminders', defaultReminders());
  if (!DB.get('plan')) await DB.set('plan', defaultPlan());
  if (!DB.get('products')) await DB.set('products', defaultProducts());
  if (!DB.get('words')) await DB.set('words', []);
  if (!DB.get('eng')) await DB.set('eng', { ratings: {}, reviews: {} });
  if (!DB.get('ach')) await DB.set('ach', {});
}

/* ============ الوصول للبيانات ============ */
const settings = () => ({ ...defaultSettings(), ...(DB.get('settings') || {}) });
const tasks = () => DB.get('tasks', []);
const dayRec = k => DB.get('day:' + k, null);
function saveDay(k, fn) { const r = dayRec(k) || { done: {} }; if (!r.done) r.done = {}; fn(r); return DB.set('day:' + k, r); }
const scheduled = k => { const wd = parseKey(k).getDay(); return tasks().filter(t => t.days.includes(wd)); };
const doneCount = r => (r && r.done ? Object.keys(r.done).length : 0);
const engMin = r => (r && r.eng ? Object.values(r.eng).reduce((a, b) => a + (+b || 0), 0) : 0);
const isActive = r => !!(r && ((+r.walk || 0) > 0 || (r.ex && r.ex.length)));

function dayStats(k) {
  const r = dayRec(k), done = doneCount(r), today = todayKey();
  let total = scheduled(k).length;
  if (k < today && r && r.total != null) total = r.total;
  total = Math.max(total, done);
  const pct = total ? Math.round(done / total * 100) : 0;
  return { done, total, left: Math.max(0, total - done), pct, logged: done > 0 || !!(r && (r.water || r.meals || r.review || r.eng || r.walk || (r.ex && r.ex.length))) };
}

async function toggleTask(k, id) {
  const t = tasks().find(x => x.id === id);
  await saveDay(k, r => {
    if (r.done[id]) delete r.done[id];
    else { const t2 = t || { points: 10, name: id, cat: 'home' }; r.done[id] = { p: +t2.points || 0, n: t2.name, c: t2.cat, at: Date.now() }; }
    r.total = Math.max(scheduled(k).length, doneCount(r));
  });
  return !!dayRec(k).done[id];
}

// إنجاز تلقائي لمهام الماء والكلمات
async function syncAuto(k) {
  const s = settings(), r = dayRec(k) || { done: {} };
  const words = (DB.get('words', [])).filter(w => w.date === k).length;
  for (const t of scheduled(k)) {
    if (!t.auto) continue;
    const ok = t.auto === 'water' ? (+r.water || 0) >= s.waterGoal : words >= 5;
    const cur = (dayRec(k) || { done: {} }).done[t.id];
    if (ok && !cur) await saveDay(k, rr => { rr.done[t.id] = { p: +t.points, n: t.name, c: t.cat, auto: 1, at: Date.now() }; rr.total = Math.max(scheduled(k).length, doneCount(rr)); });
    if (!ok && cur && cur.auto) await saveDay(k, rr => { delete rr.done[t.id]; });
  }
}

function allDayKeys() { return DB.keys('day:').map(k => k.slice(4)).sort(); }
function totalPoints() { let s = 0; for (const k of allDayKeys()) { const r = dayRec(k); if (r && r.done) for (const v of Object.values(r.done)) s += +v.p || 0; } return s; }
function pointsIn(prefix) { let s = 0; for (const k of allDayKeys()) if (k.startsWith(prefix)) { const r = dayRec(k); if (r && r.done) for (const v of Object.values(r.done)) s += +v.p || 0; } return s; }
function levelOf(p) { let i = 0; LEVELS.forEach((l, j) => { if (p >= l.at) i = j; }); const cur = LEVELS[i], nxt = LEVELS[i + 1]; return { i, cur, nxt, pct: nxt ? Math.round((p - cur.at) / (nxt.at - cur.at) * 100) : 100 }; }
function streak() {
  let k = todayKey(), n = 0;
  if (!doneCount(dayRec(k))) k = addDays(k, -1);
  while (doneCount(dayRec(k)) && n < 4000) { n++; k = addDays(k, -1); }
  return n;
}
const weekStartKey = k => { const d = parseKey(k); const ws = settings().weekStart; const diff = (d.getDay() - ws + 7) % 7; d.setDate(d.getDate() - diff); return keyOf(d); };
function sportWeekCount(k) { const s = weekStartKey(k); let n = 0; for (let i = 0; i < 7; i++) if (isActive(dayRec(addDays(s, i)))) n++; return n; }
function weekEngMinutes(k) { const s = weekStartKey(k); let n = 0; for (let i = 0; i < 7; i++) n += engMin(dayRec(addDays(s, i))); return n; }
function totalEngHours() { let m = 0; for (const k of allDayKeys()) m += engMin(dayRec(k)); return m / 60; }

function topPriorities(k) {
  const sched = scheduled(k), done = (dayRec(k) || {}).done || {};
  const stars = sched.filter(t => t.star), rest = sched.filter(t => !t.star && !done[t.id]);
  return [...stars, ...rest].slice(0, 3);
}
function motivation(pct) {
  const h = new Date().getHours(), pool = h < 12 ? MOTIV.morning : h < 17 ? MOTIV.noon : MOTIV.evening;
  const seed = Math.floor(Date.now() / 864e5);
  let m = pool[seed % pool.length];
  if (pct >= 100) m = 'ما شاء الله! يوم مكتمل 🌷 تستحقين لحظة راحة وفخر.';
  else if (pct >= 70) m = 'أنتِ قريبة جداً 🌿 ما أنجزتِه رائع، وما تبقى بخفة.';
  return m;
}

/* ============ الإنجازات ============ */
const PRAYERS = ['w_fajr', 'w_dhuhr', 'w_asr', 'w_maghrib', 'w_isha'];
const ACH = [
  { id: 'first', e: '🌱', n: 'أول خطوة', d: 'أكملتِ أول مهمة', f: s => s.pts > 0 },
  { id: 'half', e: '🌿', n: 'نصف اليوم', d: 'أنجزتِ 50٪ من مهام يوم', f: s => s.best >= 50 },
  { id: 'full', e: '🌷', n: 'يوم مكتمل', d: 'أنجزتِ كل مهام يوم', f: s => s.best >= 100 },
  { id: 's3', e: '🔥', n: 'ثلاثة أيام', d: '3 أيام متتالية من الحضور', f: s => s.streak >= 3 },
  { id: 's7', e: '🌸', n: 'أسبوع جميل', d: '7 أيام متتالية', f: s => s.streak >= 7 },
  { id: 's30', e: '🌳', n: 'شهر من الاستمرار', d: '30 يوماً متتالية', f: s => s.streak >= 30 },
  { id: 'p100', e: '⭐', n: '100 نقطة', d: 'جمعتِ 100 نقطة', f: s => s.pts >= 100 },
  { id: 'p500', e: '🌟', n: '500 نقطة', d: 'جمعتِ 500 نقطة', f: s => s.pts >= 500 },
  { id: 'p1000', e: '💫', n: '1000 نقطة', d: 'جمعتِ 1000 نقطة', f: s => s.pts >= 1000 },
  { id: 'pray', e: '🕌', n: 'خمس صلوات', d: 'أتممتِ الصلوات الخمس في يوم', f: s => s.pray },
  { id: 'water', e: '💧', n: 'يوم الماء', d: 'بلغتِ هدف الماء', f: s => s.water },
  { id: 'eng30', e: '📖', n: 'نصف ساعة إنجليزية', d: 'أتممتِ هدف الإنجليزية اليومي', f: s => s.eng },
  { id: 'words50', e: '🔤', n: '50 كلمة', d: 'دوّنتِ 50 كلمة جديدة', f: s => s.words >= 50 },
  { id: 'sport', e: '🏃‍♀️', n: 'أسبوع نشيط', d: 'بلغتِ هدف الأيام النشطة في أسبوع', f: s => s.sportWeek },
];
function achStats() {
  const st = settings(); let best = 0, pray = false, water = false, eng = false, sportWeek = false;
  const weeks = new Set();
  for (const k of allDayKeys()) {
    const r = dayRec(k); best = Math.max(best, dayStats(k).pct);
    if (r.done && PRAYERS.every(p => r.done[p])) pray = true;
    if ((+r.water || 0) >= st.waterGoal) water = true;
    if (engMin(r) >= st.engGoal) eng = true;
    weeks.add(weekStartKey(k));
  }
  for (const w of weeks) if (sportWeekCount(w) >= st.sportGoal) sportWeek = true;
  return { pts: totalPoints(), best, streak: streak(), pray, water, eng, words: DB.get('words', []).length, sportWeek };
}
async function checkAch() {
  const s = achStats(), have = { ...(DB.get('ach') || {}) }, fresh = [];
  for (const a of ACH) if (!have[a.id] && a.f(s)) { have[a.id] = todayKey(); fresh.push(a); }
  if (fresh.length) { await DB.set('ach', have); toast(`🎉 إنجاز جديد: ${fresh[0].n}`); }
}

/* ============ الإشعارات ============ */
const Notif = {
  supported: () => 'Notification' in window && 'serviceWorker' in navigator,
  perm: () => ('Notification' in window ? Notification.permission : 'unsupported'),
  async ask() {
    if (!Notif.supported()) return 'unsupported';
    const p = await Notification.requestPermission();
    if (p === 'granted') await Notif.registerPeriodic();
    return p;
  },
  async registerPeriodic() {
    try {
      const reg = await navigator.serviceWorker.ready;
      if ('periodicSync' in reg) await reg.periodicSync.register('check-reminders', { minInterval: 15 * 60 * 1000 });
    } catch { }
  },
  async show(title, body, tag) {
    const reg = await navigator.serviceWorker.ready;
    return reg.showNotification(title, { body, tag, icon: 'icons/icon-192.png', badge: 'icons/icon-192.png', lang: 'ar', dir: 'rtl', vibrate: [120, 60, 120], data: { url: './index.html#/tasks' } });
  },
  bodyFor(r) {
    const st = dayStats(todayKey());
    if (r.id === 'midday' || r.id === 'evening') return `${r.body}\nإنجاز اليوم: ${st.pct}٪ (${st.done}/${st.total})`;
    return r.body;
  },
  // يعمل أثناء فتح التطبيق أو بقائه في الخلفية
  async check() {
    if (Notif.perm() !== 'granted' || DB.get('pushSub')) return;
    const rem = DB.get('reminders', []), st = (await DB.getFresh('notifState')) || {};
    const now = new Date(), nowMin = now.getHours() * 60 + now.getMinutes(), today = todayKey();
    let changed = false;
    for (const r of rem) {
      if (!r.on || !/^\d\d:\d\d$/.test(r.time)) continue;
      const [h, m] = r.time.split(':').map(Number), diff = nowMin - (h * 60 + m);
      if (diff >= 0 && diff <= 90 && st[r.id] !== today) { st[r.id] = today; changed = true; await Notif.show('منظم حياتي 🌷', Notif.bodyFor(r), r.id + '-' + today); }
    }
    if (changed) await DB.set('notifState', st);
  },
};

/* ============ إشعارات الدفع (Push) عبر خادم اختياري ============ */
const Push = {
  base() { const s = settings().server.trim().replace(/\/+$/, ''); return s || (location.protocol.startsWith('http') ? location.origin : ''); },
  b64(s) { const p = '='.repeat((4 - s.length % 4) % 4), b = (s + p).replace(/-/g, '+').replace(/_/g, '/'), r = atob(b); return Uint8Array.from([...r].map(c => c.charCodeAt(0))); },
  async available() { try { const r = await fetch(Push.base() + '/api/health', { cache: 'no-store' }); return r.ok && (await r.json()).ok === true; } catch { return false; } },
  async subscribe() {
    const base = Push.base();
    if (!base) throw new Error('لا يوجد عنوان خادم');
    const reg = await navigator.serviceWorker.ready;
    const { key } = await (await fetch(base + '/api/vapid')).json();
    let sub = await reg.pushManager.getSubscription();
    if (!sub) sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: Push.b64(key) });
    await DB.set('pushSub', sub.toJSON());
    await Push.sync();
    return sub;
  },
  async unsubscribe() {
    try {
      const reg = await navigator.serviceWorker.ready, sub = await reg.pushManager.getSubscription();
      if (sub) { try { await fetch(Push.base() + '/api/unsubscribe', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ endpoint: sub.endpoint }) }); } catch { } await sub.unsubscribe(); }
    } catch { }
    await DB.del('pushSub');
  },
  async sync() {
    const sub = DB.get('pushSub'); if (!sub) return;
    try {
      await fetch(Push.base() + '/api/sync', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subscription: sub, tz: Intl.DateTimeFormat().resolvedOptions().timeZone, reminders: DB.get('reminders', []).map(r => ({ id: r.id, label: r.label, time: r.time, on: r.on, body: r.body })) }),
      });
    } catch { }
  },
  async test() {
    const sub = DB.get('pushSub'); if (!sub) throw new Error('غير مرتبط');
    const r = await fetch(Push.base() + '/api/test', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ endpoint: sub.endpoint }) });
    if (!r.ok) throw new Error('فشل الإرسال');
  },
};

/* ============ نسخ احتياطي ============ */
function exportBackup() {
  const blob = new Blob([JSON.stringify({ app: 'my-life-organizer', version: 1, exportedAt: new Date().toISOString(), data: DB.dump() })], { type: 'application/json' });
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `منظم-حياتي-${todayKey()}.json`; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}
async function importBackup(file) {
  const j = JSON.parse(await file.text());
  if (j.app !== 'my-life-organizer' || !j.data) throw new Error('ملف غير صالح');
  await DB.clearAll();
  for (const [k, v] of Object.entries(j.data)) await DB.set(k, v);
  await seed();
}

/* ============ واجهة مساعدة ============ */
let toastT;
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 2400); }
function applyTheme() { document.documentElement.dataset.theme = settings().theme; const m = $('meta[name=theme-color]'); if (m) m.content = (document.documentElement.dataset.theme === 'dark' || (settings().theme === 'auto' && matchMedia('(prefers-color-scheme:dark)').matches)) ? '#1D1F18' : '#6B7A3A'; }
