'use strict';
/* ============ الحالة ============ */
const S = { today: todayKey(), viewDate: todayKey(), filter: 'all', collapsed: {}, calMonth: todayKey().slice(0, 7), calSel: todayKey(), mrMonth: todayKey().slice(0, 7), fc: { i: 0, flip: false }, installEvt: null };

/* ============ عناصر مشتركة ============ */
const fmtDate = k => { const d = parseKey(k); return `${DAYS[d.getDay()]} ${d.getDate()} ${MONTHS[d.getMonth()]}`; };
const clockStr = () => { const d = new Date(); return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`; };
function hijriStr() { try { return new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura-nu-latn', { day: 'numeric', month: 'long', year: 'numeric' }).format(new Date()); } catch { return ''; } }
const checkSVG = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
const bloom = 'M50 10C38 14 24 22 24 42C24 58 36 68 50 68C64 68 76 58 76 42C76 22 62 14 50 10Z';
function tulipSVG(p) {
  const y = (68 - 58 * clamp(p, 0, 100) / 100).toFixed(1);
  return `<svg class="tulip" viewBox="0 0 100 124" role="img" aria-label="اكتمال الزهرة ${p}%"><defs><clipPath id="tc"><rect x="0" y="${y}" width="100" height="124"/></clipPath></defs>
  <path d="M50 66V118" stroke="var(--olive)" stroke-width="4" stroke-linecap="round"/>
  <path d="M50 110C34 106 22 94 20 80C34 82 46 92 50 102Z" fill="var(--olive)"/><path d="M50 110C66 106 78 94 80 80C66 82 54 92 50 102Z" fill="var(--olive)" opacity=".75"/>
  <path d="${bloom}" fill="var(--surface2)" stroke="var(--line)" stroke-width="1.5"/>
  <path d="${bloom}" fill="var(--rose)" clip-path="url(#tc)"/>
  <path d="M50 12C43 30 43 50 50 67M36 20C34 38 40 56 50 67M64 20C66 38 60 56 50 67" stroke="#fff" stroke-opacity=".35" fill="none" stroke-width="1.5"/></svg>`;
}
function pageHead(title, back) {
  return `<header class="row mb">${back ? `<a class="icon-btn" href="#${back}" aria-label="رجوع" style="text-decoration:none">→</a>` : ''}<h1 class="display grow" style="font-size:1.7rem">${title}</h1></header>`;
}
function taskRow(t, k, rec, o = {}) {
  const d = rec && rec.done && rec.done[t.id];
  return `<div class="task ${d ? 'done' : ''}">
    <button class="check" data-a="toggle" data-id="${t.id}" data-k="${k}" aria-pressed="${!!d}" aria-label="${d ? 'إلغاء إنجاز' : 'تسجيل إنجاز'}: ${esc(t.name)}">${checkSVG}</button>
    <div class="nm" data-a="edit" data-id="${t.id}">${esc(t.name)}${(t.time || t.auto || o.cat) ? `<div class="meta">${t.time ? '⏰ ' + t.time + ' ' : ''}${t.auto ? '⚙️ تلقائي ' : ''}${o.cat ? catOf(t.cat).ic + ' ' + catOf(t.cat).name : ''}</div>` : ''}</div>
    <span class="pts">+${t.points}</span>
    ${o.noStar ? '' : `<button class="star ${t.star ? 'on' : ''}" data-a="star" data-id="${t.id}" aria-label="أولوية" aria-pressed="${!!t.star}">★</button>`}
  </div>`;
}
const chipsHTML = (opts, cur, action, extra = '') => `<div class="chips">${opts.map(([v, l]) => `<button class="chip ${String(cur) === String(v) ? 'on' : ''}" data-a="${action}" data-v="${v}" ${extra}>${l}</button>`).join('')}</div>`;
function openSheet(html) { $('#sheet-root').innerHTML = `<div class="scrim" data-a="closesheet"></div><div class="sheet" role="dialog" aria-modal="true"><div class="grab"></div>${html}</div>`; }
const closeSheet = () => { $('#sheet-root').innerHTML = ''; };

/* ============ الرئيسية ============ */
function vHome() {
  const k = todayKey(), st = dayStats(k), s = settings(), rec = dayRec(k) || { done: {} }, d = new Date();
  const lv = levelOf(totalPoints()), pri = topPriorities(k), hj = hijriStr();
  return `
  <section class="hero">
    <div class="brand">MY LIFE ORGANIZER 🌷</div>
    <div class="row">
      <div class="grow">
        <div class="date">${DAYS[d.getDay()]}<br>${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}</div>
        ${hj ? `<div class="hijri">${hj}</div>` : ''}
        <div class="clock" id="clock">${clockStr()}</div>
      </div>${tulipSVG(st.pct)}
    </div>
    <p class="msg">${s.name ? esc(s.name) + '، ' : ''}${motivation(st.pct)}</p>
  </section>

  <section class="card mt" aria-label="إنجاز اليوم">
    <div class="row between mb"><div><span class="pct-big">${st.pct}%</span> <span class="muted small">من مهام اليوم</span></div><span class="chip">${lv.cur.e} ${lv.cur.n}</span></div>
    <div class="bar" role="progressbar" aria-valuenow="${st.pct}" aria-valuemin="0" aria-valuemax="100"><i style="width:${st.pct}%"></i></div>
    <div class="row gap mt"><div class="stat"><b>${st.done}</b><span>منجزة</span></div><div class="stat"><b>${st.left}</b><span>متبقية</span></div><div class="stat"><b>${streak()}</b><span>أيام متتالية</span></div></div>
  </section>

  <h2 class="sec">أهم ثلاث أولويات اليوم</h2>
  <section class="card">${pri.length ? pri.map(t => taskRow(t, k, rec, { noStar: true, cat: 1 })).join('') : '<p class="muted center">لا مهام لليوم. استمتعي بيوم هادئ 🌿</p>'}</section>

  <div class="actions mt">
    <button class="btn" data-a="startday">☀️ بدء اليوم</button>
    <button class="btn rose" data-a="reviewday">🌙 مراجعة اليوم</button>
    <a class="btn soft wide" href="#/calendar" style="text-decoration:none">📅 عرض التقويم الشهري</a>
  </div>
  <div class="card mt row between"><div class="row gap"><span style="font-size:1.6rem">💧</span><div><b>${+rec.water || 0}</b> / ${s.waterGoal} كأس</div></div><button class="btn sm soft" data-a="water+">+ كأس</button></div>`;
}

/* ============ المهام ============ */
function vTasks() {
  const k = S.viewDate, st = dayStats(k), rec = dayRec(k) || { done: {} }, list = scheduled(k), isT = k === todayKey();
  let shown = list;
  if (S.filter === 'ess') shown = list.filter(t => t.star);
  if (S.filter === 'left') shown = list.filter(t => !rec.done[t.id]);
  const groups = CATS.map(c => {
    const all = list.filter(t => t.cat === c.id), vis = shown.filter(t => t.cat === c.id);
    if (!all.length && S.filter === 'all') return '';
    const dn = all.filter(t => rec.done[t.id]).length, open = !S.collapsed[c.id];
    return `<section class="cat card">
      <button class="cat-h" data-a="collapse" data-id="${c.id}" aria-expanded="${open}"><span class="ci">${c.ic}</span><span class="t">${c.name}</span><span class="c">${dn}/${all.length}</span><span>${open ? '⌃' : '⌄'}</span></button>
      ${open ? (vis.length ? vis.map(t => taskRow(t, k, rec)).join('') : '<p class="muted small center">لا شيء هنا ✨</p>') : ''}
      ${open ? `<button class="btn sm ghost block mt" data-a="addtask" data-cat="${c.id}">+ إضافة مهمة في ${c.name}</button>` : ''}
    </section>`;
  }).join('');
  return `${pageHead('مهام اليوم')}
  <div class="card"><div class="daynav"><button class="icon-btn" data-a="day" data-v="-1" aria-label="اليوم السابق">→</button><div class="lbl">${isT ? 'اليوم · ' : ''}${fmtDate(k)}</div><button class="icon-btn" data-a="day" data-v="1" aria-label="اليوم التالي">←</button></div>
    ${!isT ? '<button class="btn sm soft block mt" data-a="daytoday">العودة إلى اليوم</button>' : ''}
    <div class="row between mt"><b>${st.pct}%</b><span class="muted small">${st.done} من ${st.total}</span></div><div class="bar mt"><i style="width:${st.pct}%"></i></div></div>
  <div class="chips mt mb">${[['all', 'الكل'], ['ess', '⭐ الأساسيات'], ['left', 'المتبقية']].map(([v, l]) => `<button class="chip ${S.filter === v ? 'on' : ''}" data-a="filter" data-v="${v}">${l}</button>`).join('')}<button class="chip rose" data-a="addtask">+ مهمة جديدة</button></div>
  ${groups || '<p class="muted center">لا توجد مهام لهذا اليوم.</p>'}`;
}

/* ============ التقويم ============ */
function levelCls(p) { return p <= 0 ? '' : p < 25 ? 'l1' : p < 50 ? 'l2' : p < 80 ? 'l3' : 'l4'; }
function vCalendar() {
  const [y, m] = S.calMonth.split('-').map(Number), ws = settings().weekStart, td = todayKey();
  const first = new Date(y, m - 1, 1), n = new Date(y, m, 0).getDate(), off = (first.getDay() - ws + 7) % 7;
  const head = [...Array(7)].map((_, i) => `<div class="wd">${DAYS_SHORT[(ws + i) % 7]}</div>`).join('');
  let cells = '<div class="d out"></div>'.repeat(off), logged = 0, elapsed = 0, sumPct = 0, doneTotal = 0;
  const weeks = []; let cur = null;
  for (let i = 1; i <= n; i++) {
    const k = `${y}-${pad(m)}-${pad(i)}`, st = dayStats(k), fut = k > td, past = k < td;
    if (!fut) { elapsed++; if (st.logged) { logged++; sumPct += st.pct; doneTotal += st.done; } }
    const cls = [levelCls(st.pct), k === td ? 'today' : '', k === S.calSel ? 'sel' : '', past && !st.logged ? 'miss' : '', fut ? 'out-f' : ''].join(' ');
    cells += `<button class="d ${cls}" data-a="calsel" data-k="${k}" ${fut ? 'style="opacity:.55"' : ''} aria-label="${fmtDate(k)}: ${st.pct}%">${i}${st.logged ? `<small>${st.pct}%</small>` : ''}</button>`;
    const idx = (off + i - 1);
    if (!cur || idx % 7 === 0) { cur = { from: i, to: i, pct: 0, days: 0, done: 0 }; weeks.push(cur); }
    cur.to = i; if (!fut && st.logged) { cur.pct += st.pct; cur.days++; cur.done += st.done; }
  }
  const sel = S.calSel, sst = dayStats(sel), srec = dayRec(sel);
  const doneList = srec && srec.done ? Object.values(srec.done).map(v => `<div class="li" style="min-height:44px"><span class="ico" style="font-size:1.1rem">${catOf(v.c).ic}</span><span class="grow">${esc(v.n)}</span><span class="pts small muted">+${v.p}</span></div>`).join('') : '';
  const mpts = pointsIn(S.calMonth);
  return `${pageHead('التقويم')}
  <div class="card"><div class="daynav"><button class="icon-btn" data-a="month" data-v="-1" aria-label="الشهر السابق">→</button><div class="lbl display" style="font-size:1.3rem">${MONTHS[m - 1]} ${y}</div><button class="icon-btn" data-a="month" data-v="1" aria-label="الشهر التالي">←</button></div>
    <div class="cal mt">${head}${cells}</div>
    <div class="legend">أقل <i style="background:#EEF1DC"></i><i style="background:#D9E2B4"></i><i style="background:#B7C97F"></i><i style="background:#8FAA4E"></i> أكثر · ◦ يوم بلا تسجيل</div></div>

  <div class="card"><div class="row between"><b>${fmtDate(sel)}</b><span class="chip ${sst.pct >= 70 ? 'on' : ''}">${sst.pct}% التزام</span></div>
    <p class="muted small">${sst.done} منجزة من ${sst.total}${srec && srec.review ? ' · ' + srec.review.mood : ''}</p>
    ${doneList || `<p class="muted small">${sel > td ? 'يوم قادم 🌷' : 'لا إنجازات مسجّلة لهذا اليوم، ولا بأس بذلك.'}</p>`}
    ${srec && srec.review && srec.review.note ? `<p class="card olive small">${esc(srec.review.note)}</p>` : ''}
    <button class="btn soft block mt" data-a="openday" data-k="${sel}">فتح هذا اليوم لتسجيل المهام</button></div>

  <h2 class="sec">ملخص ${MONTHS[m - 1]}</h2>
  <div class="card"><div class="row gap"><div class="stat"><b>${logged ? Math.round(sumPct / logged) : 0}%</b><span>متوسط الإنجاز</span></div><div class="stat"><b>${logged}/${elapsed}</b><span>أيام مسجّلة</span></div></div>
    <div class="row gap mt"><div class="stat"><b>${doneTotal}</b><span>مهمة منجزة</span></div><div class="stat"><b>${mpts}</b><span>نقطة</span></div></div>
    ${elapsed - logged > 0 ? `<p class="muted small mt">${elapsed - logged} يوم بلا تسجيل. لا بأس، المهم أن تبدئي من اليوم 🌿</p>` : '<p class="small mt">ما شاء الله، سجّلتِ كل الأيام 🌷</p>'}</div>
  <h2 class="sec">الأسابيع</h2>
  <div class="card">${weeks.map((w, i) => `<div class="li"><span class="ico">🗓️</span><div class="grow"><b>الأسبوع ${i + 1}</b> <span class="muted small">(${w.from}–${w.to})</span><div class="bar mt" style="height:8px"><i style="width:${w.days ? Math.round(w.pct / w.days) : 0}%"></i></div></div><span class="small muted">${w.days ? Math.round(w.pct / w.days) : 0}% · ${w.days} أيام</span></div>`).join('')}</div>`;
}

/* ============ إنجازاتي ============ */
function vProgress() {
  const pts = totalPoints(), lv = levelOf(pts), td = todayKey(), ym = S.mrMonth;
  const bars = [...Array(7)].map((_, i) => { const k = addDays(td, i - 6), st = dayStats(k); return `<div class="b ${k === td ? 'today' : ''}"><span>${st.pct}</span><i style="height:${Math.max(4, st.pct * 0.9)}px"></i><span>${DAYS_SHORT[parseKey(k).getDay()]}</span></div>`; }).join('');
  let wAvg = 0, wDays = 0; for (let i = 0; i < 7; i++) { const st = dayStats(addDays(td, -i)); if (st.logged) { wAvg += st.pct; wDays++; } }
  const catCount = {}; let mDone = 0, mDays = 0, mSum = 0;
  allDayKeys().filter(k => k.startsWith(td.slice(0, 7))).forEach(k => { const r = dayRec(k); if (!doneCount(r)) return; mDays++; mSum += dayStats(k).pct; Object.values(r.done).forEach(v => { catCount[v.c] = (catCount[v.c] || 0) + 1; mDone++; }); });
  const maxC = Math.max(1, ...Object.values(catCount)), have = DB.get('ach') || {};
  const mr = DB.get('mr:' + ym) || { r: {} };
  const [my, mm] = ym.split('-').map(Number);
  return `${pageHead('إنجازاتي')}
  <section class="card blush"><div class="level-ring"><div style="font-size:3rem">${lv.cur.e}</div><div class="grow"><div class="display" style="font-size:1.5rem">مستوى: ${lv.cur.n}</div><div class="small">${pts} نقطة${lv.nxt ? ` · ${lv.nxt.at - pts} نقطة للمستوى «${lv.nxt.n}» ${lv.nxt.e}` : ' · أعلى مستوى 👑'}</div><div class="bar rose mt"><i style="width:${lv.pct}%"></i></div></div></div></section>
  <h2 class="sec">آخر 7 أيام</h2>
  <div class="card"><div class="bars">${bars}</div><p class="muted small center mt">${wDays ? `متوسط الأسبوع ${Math.round(wAvg / wDays)}% في ${wDays} أيام مسجّلة` : 'ابدئي بتسجيل أول مهمة 🌱'}</p></div>
  <h2 class="sec">هذا الشهر</h2>
  <div class="card"><div class="row gap"><div class="stat"><b>${mDays ? Math.round(mSum / mDays) : 0}%</b><span>متوسط الإنجاز</span></div><div class="stat"><b>${mDays}</b><span>أيام نشطة</span></div><div class="stat"><b>${mDone}</b><span>مهمة</span></div></div>
    ${CATS.map(c => `<div class="li" style="min-height:44px"><span class="ico">${c.ic}</span><span style="width:96px" class="small">${c.name}</span><div class="bar grow" style="height:9px"><i style="width:${Math.round((catCount[c.id] || 0) / maxC * 100)}%"></i></div><span class="small muted" style="width:28px;text-align:end">${catCount[c.id] || 0}</span></div>`).join('')}</div>
  <h2 class="sec">سجل الإنجازات</h2>
  <div class="card">${ACH.map(a => `<div class="badge ${have[a.id] ? '' : 'lock'}"><div class="e">${a.e}</div><div class="grow"><b>${a.n}</b><div class="small muted">${a.d}</div></div>${have[a.id] ? `<span class="small muted">${fmtDate(have[a.id])}</span>` : '<span>🔒</span>'}</div>`).join('')}</div>
  <h2 class="sec">تقييم نهاية الشهر</h2>
  <div class="card"><div class="daynav"><button class="icon-btn" data-a="mrmonth" data-v="-1" aria-label="الشهر السابق">→</button><div class="lbl">${MONTHS[mm - 1]} ${my}</div><button class="icon-btn" data-a="mrmonth" data-v="1" aria-label="الشهر التالي">←</button></div>
    <p class="muted small">قيّمي كل مجال بين 1 و5. لا توجد إجابات خاطئة 🤍</p>
    ${CATS.map(c => `<div class="li" style="flex-wrap:wrap"><span class="ico">${c.ic}</span><span class="grow">${c.name}</span><div class="chips">${[1, 2, 3, 4, 5].map(n => `<button class="chip ${mr.r[c.id] === n ? 'on' : ''}" data-a="mrate" data-c="${c.id}" data-v="${n}" style="min-width:38px;justify-content:center">${n}</button>`).join('')}</div></div>`).join('')}
    <label class="f">ما الذي سار جيداً هذا الشهر؟</label><textarea data-save="mr:good" placeholder="أنا فخورة بـ…">${esc(mr.good || '')}</textarea>
    <label class="f">ما الذي أريد تحسينه بلطف؟</label><textarea data-save="mr:improve">${esc(mr.improve || '')}</textarea>
    <label class="f">نيّتي للشهر القادم</label><textarea data-save="mr:next">${esc(mr.next || '')}</textarea></div>`;
}

/* ============ المزيد ============ */
function vMore() {
  const L = [['#/english', '🔤', 'الإنجليزية', 'من B1 إلى B2'], ['#/health', '🥗', 'التغذية والرياضة', 'وجبات، ماء، نشاط'], ['#/care', '🏡', 'المنزل والعناية', 'جدول التنظيف وروتين البشرة'], ['#/settings', '⚙️', 'الإعدادات', 'الإشعارات، الأهداف، النسخ الاحتياطي']];
  return `${pageHead('المزيد')}${L.map(([h, i, t, d]) => `<a class="card-link" href="${h}"><span class="ci">${i}</span><div class="grow"><b>${t}</b><div class="small muted">${d}</div></div><span>‹</span></a>`).join('')}`;
}

/* ============ الإنجليزية ============ */
function vEnglish() {
  const s = settings(), k = todayKey(), rec = dayRec(k) || {}, mins = engMin(rec), words = DB.get('words', []), eng = DB.get('eng'), tm = DB.get('engTimer');
  const hrs = totalEngHours(), prog = clamp(Math.round(hrs / s.engTargetHours * 100), 0, 100), wk = weekStartKey(k), rev = (eng.reviews || {})[wk] || '';
  const pw = words.filter(w => w.date >= wk).length;
  return `${pageHead('الإنجليزية 🔤', '/more')}
  <div class="card olive"><div class="row between"><b>هدف اليوم: ${s.engGoal} دقيقة</b><span class="chip ${mins >= s.engGoal ? 'on' : ''}">${mins} د</span></div>
    <div class="bar mt"><i style="width:${clamp(Math.round(mins / s.engGoal * 100), 0, 100)}%"></i></div>
    <div class="small muted mt">${Object.entries(SKILLS).map(([a, n]) => (rec.eng && rec.eng[a] ? `${n}: ${rec.eng[a]}د` : '')).filter(Boolean).join(' · ') || 'لم تسجّلي دقائق اليوم بعد'}</div></div>

  <h2 class="sec">سجّلي دقائقك</h2>
  <div class="card">
    ${tm ? `<div class="center"><div class="display" style="font-size:2.4rem;direction:ltr" id="etimer">00:00</div><div class="muted small">جلسة ${SKILLS[tm.skill]} جارية</div><button class="btn block mt" data-a="etimer-stop">⏹ إنهاء وحفظ الجلسة</button></div>`
      : `<label class="f" style="margin-top:0">المهارة</label>${chipsHTML(Object.entries(SKILLS), S.skill || 'listening', 'skill')}
        <div class="row gap mt"><button class="btn grow" data-a="etimer-start">▶ بدء مؤقّت</button></div>
        <label class="f">أو أضيفي دقائق مباشرة</label><div class="chips">${[5, 10, 15, 30].map(n => `<button class="chip" data-a="engadd" data-v="${n}">+${n} د</button>`).join('')}</div>`}
  </div>

  <h2 class="sec">الوصول إلى B2</h2>
  <div class="card"><div class="row between"><b>B1 ⟶ B2</b><span class="small muted">${hrs.toFixed(1)} من ${s.engTargetHours} ساعة</span></div><div class="bar mt"><i style="width:${prog}%"></i></div>
    <label class="f">تقييمي لنفسي (1–5)</label>
    ${Object.entries(SKILLS).map(([a, n]) => `<div class="li" style="min-height:48px"><span class="grow">${n}</span><div class="chips">${[1, 2, 3, 4, 5].map(v => `<button class="chip ${((eng.ratings || {})[a]) === v ? 'on' : ''}" data-a="erate" data-c="${a}" data-v="${v}" style="min-width:36px;justify-content:center;min-height:36px">${v}</button>`).join('')}</div></div>`).join('')}</div>

  <h2 class="sec">كلماتي (${words.length})</h2>
  <div class="card"><label class="f" style="margin-top:0">كلمة جديدة</label><input type="text" id="w-w" placeholder="Word" dir="ltr" autocomplete="off">
    <label class="f">المعنى</label><input type="text" id="w-m" placeholder="المعنى بالعربية">
    <label class="f">جملة مثال (اختياري)</label><input type="text" id="w-e" dir="ltr" placeholder="Example sentence">
    <div class="row gap mt"><button class="btn grow" data-a="addword">+ حفظ الكلمة</button>${words.length ? '<button class="btn soft" data-a="flash">🃏 مراجعة</button>' : ''}</div>
    <p class="muted small">كلمات اليوم: ${words.filter(w => w.date === k).length}/5 ${words.filter(w => w.date === k).length >= 5 ? '✅' : ''}</p></div>
  ${words.length ? `<div class="card">${[...words].reverse().slice(0, 40).map(w => `<div class="li"><button class="check" style="width:36px;height:36px;border-radius:12px;${w.learned ? 'background:var(--ok);border-color:var(--ok)' : ''}" data-a="wlearn" data-id="${w.id}" aria-label="تم حفظها" aria-pressed="${!!w.learned}"><span style="color:#fff">${w.learned ? '✓' : ''}</span></button><div class="grow"><b dir="ltr">${esc(w.w)}</b> — ${esc(w.m)}${w.ex ? `<div class="small muted" dir="ltr">${esc(w.ex)}</div>` : ''}</div><button class="icon-btn" data-a="wdel" data-id="${w.id}" aria-label="حذف">🗑</button></div>`).join('')}</div>` : ''}

  <h2 class="sec">أفكار للتدريب</h2>
  <div class="card">${Object.entries(SKILL_IDEAS).map(([a, arr]) => `<div class="li" style="align-items:flex-start"><span class="chip" style="min-width:64px;justify-content:center">${SKILLS[a]}</span><ul class="grow small" style="margin:0;padding-inline-start:18px">${arr.map(x => `<li>${x}</li>`).join('')}</ul></div>`).join('')}</div>

  <h2 class="sec">المراجعة الأسبوعية</h2>
  <div class="card"><div class="row gap"><div class="stat"><b>${weekEngMinutes(k)}</b><span>دقيقة هذا الأسبوع</span></div><div class="stat"><b>${pw}</b><span>كلمة جديدة</span></div></div>
    <label class="f">ما الذي تعلمتِه؟ وما الذي سأراجعه؟</label><textarea data-save="engrev">${esc(rev)}</textarea></div>`;
}

/* ============ التغذية والرياضة ============ */
function vHealth() {
  const s = settings(), k = todayKey(), rec = dayRec(k) || {}, water = +rec.water || 0, meals = rec.meals || {}, plan = DB.get('plan', {}), wd = new Date().getDay();
  const wk = sportWeekCount(k), mo = allDayKeys().filter(x => x.startsWith(k.slice(0, 7)) && isActive(dayRec(x))).length, ex = rec.ex || [];
  return `${pageHead('التغذية والرياضة 🥗', '/more')}
  <div class="card"><div class="row between"><b>💧 الماء</b><span class="small muted">${water} / ${s.waterGoal} كأس</span></div>
    <div class="chips mt">${[...Array(Math.max(s.waterGoal, water))].map((_, i) => `<button class="glass ${i < water ? 'on' : ''}" data-a="glass" data-v="${i + 1}" aria-label="كأس ${i + 1}"></button>`).join('')}</div></div>

  <h2 class="sec">وجباتي اليوم</h2>
  ${Object.entries(MEALS).map(([m, n]) => `<div class="card"><b>${n}</b><textarea data-save="meal:${m}" style="min-height:64px;margin-top:8px" placeholder="ماذا أكلتِ؟">${esc(meals[m] || '')}</textarea>
    <div class="small muted mt">اقتراحات متوازنة ومشبعة:</div><div class="chips mt">${SUGGEST[m].map((x, i) => `<button class="chip small" data-a="suggest" data-m="${m}" data-i="${i}">+ ${x}</button>`).join('')}</div></div>`).join('')}
  <div class="card"><b>ملاحظات التغذية</b><textarea data-save="nnote" style="margin-top:8px" placeholder="شهية، طاقة، ما أريد تجربته…">${esc(rec.nnote || '')}</textarea></div>

  <h2 class="sec">الرياضة</h2>
  <div class="card olive"><div class="row gap"><div class="stat"><b>${wk}/${s.sportGoal}</b><span>أيام نشطة هذا الأسبوع</span></div><div class="stat"><b>${mo}</b><span>هذا الشهر</span></div></div>
    <p class="small mt" style="margin-bottom:0">${wk >= s.sportGoal ? 'حققتِ هدف الأسبوع 🌷' : 'الهدف مرن: أي حركة تُحسب، والراحة جزء من الخطة 🌿'}</p></div>
  <div class="card"><div class="row between"><b>اليوم: ${DAYS[wd]}</b></div><p class="small">${esc(plan[wd] || 'يوم راحة')}</p>
    <label class="f">المشي (دقائق)</label><input type="number" inputmode="numeric" min="0" data-save="walk" value="${+rec.walk || ''}" placeholder="0">
    <div class="mt">${ex.map((e, i) => `<div class="li" style="min-height:44px"><span class="ico">💪</span><span class="grow">${esc(e.t)} · ${e.m} د</span><button class="icon-btn" data-a="exdel" data-i="${i}">🗑</button></div>`).join('')}</div>
    <button class="btn soft block mt" data-a="exadd">+ تسجيل تمرين</button></div>
  <h2 class="sec">جدولي الأسبوعي</h2>
  <div class="card">${[6, 0, 1, 2, 3, 4, 5].map(d => `<div class="li" style="${d === wd ? 'background:var(--olive-l);border-radius:12px;padding-inline:8px' : ''}"><b style="width:74px">${DAYS[d]}</b><input type="text" data-save="plan:${d}" value="${esc(plan[d] || '')}" aria-label="خطة ${DAYS[d]}"></div>`).join('')}</div>`;
}

/* ============ المنزل والعناية ============ */
function vCare() {
  const k = todayKey(), rec = dayRec(k) || { done: {} }, wd = new Date().getDay(), prods = DB.get('products', []), used = rec.skin || { am: [], pm: [] };
  const home = tasks().filter(t => t.cat === 'home'), care = tasks().filter(t => t.cat === 'care');
  const order = [6, 0, 1, 2, 3, 4, 5].sort((a, b) => ((a - settings().weekStart + 7) % 7) - ((b - settings().weekStart + 7) % 7));
  const slot = (id, label, ic) => `<div class="card"><b>${ic} ${label}</b>
    ${care.filter(t => t.slot === id && t.days.includes(wd)).map(t => taskRow(t, k, rec, { noStar: true })).join('')}
    <div class="small muted mt">المنتجات المستعملة اليوم:</div>
    <div class="chips mt">${prods.filter(p => p.slot === id || p.slot === 'both').map(p => `<button class="chip ${(used[id] || []).includes(p.id) ? 'on' : ''}" data-a="prod" data-s="${id}" data-id="${p.id}">${esc(p.name)}</button>`).join('') || '<span class="muted small">أضيفي منتجاتك بالأسفل</span>'}</div></div>`;
  return `${pageHead('المنزل والعناية 🏡', '/more')}
  <h2 class="sec" style="margin-top:0">جدول التنظيف الأسبوعي</h2>
  ${order.map(d => { const ts = home.filter(t => t.days.includes(d)); return `<div class="card" style="${d === wd ? 'border-color:var(--olive);border-width:2px' : ''}"><div class="row between"><b>${DAYS[d]}${d === wd ? ' · اليوم' : ''}</b><button class="btn sm ghost" data-a="addtask" data-cat="home" data-day="${d}">+</button></div>
    ${ts.map(t => d === wd ? taskRow(t, k, rec, { noStar: true }) : `<div class="li" style="min-height:44px"><span class="ico" style="font-size:1rem">▫️</span><span class="grow" data-a="edit" data-id="${t.id}">${esc(t.name)}</span></div>`).join('') || '<p class="muted small">يوم بلا تنظيف 🌿</p>'}</div>`; }).join('')}
  <h2 class="sec">العناية بالبشرة</h2>
  ${slot('am', 'روتين الصباح', '🌤️')}${slot('pm', 'روتين المساء', '🌙')}
  <div class="card"><b>منتجاتي</b>${prods.map(p => `<div class="li" style="min-height:48px"><span class="grow">${esc(p.name)}</span><span class="chip small">${{ am: 'صباحاً', pm: 'مساءً', both: 'الاثنان' }[p.slot]}</span><button class="icon-btn" data-a="proddel" data-id="${p.id}">🗑</button></div>`).join('')}
    <div class="row gap mt"><input type="text" id="np-n" placeholder="اسم المنتج" class="grow"><select id="np-s" style="width:auto"><option value="both">الاثنان</option><option value="am">صباحاً</option><option value="pm">مساءً</option></select></div><button class="btn soft block mt" data-a="prodadd">+ إضافة منتج</button>
    <label class="f">ملاحظات البشرة اليوم</label><textarea data-save="skinnote" style="min-height:64px">${esc(rec.skinnote || '')}</textarea></div>`;
}

/* ============ الإعدادات ============ */
function vSettings() {
  const s = settings(), rem = DB.get('reminders', []), perm = Notif.perm(), sub = DB.get('pushSub');
  const permTxt = { granted: '✅ مفعّلة في هذا الجهاز', denied: '⛔ محظورة. فعّليها من إعدادات الموقع في المتصفح', default: 'لم تُفعَّل بعد', unsupported: 'غير مدعومة في هذا المتصفح' }[perm];
  const num = (id, label, v) => `<label class="f">${label}</label><input type="number" inputmode="numeric" min="1" data-save="set:${id}" value="${v}">`;
  return `${pageHead('الإعدادات ⚙️', '/more')}
  <div class="card"><label class="f" style="margin-top:0">اسمك (يظهر في الرسائل)</label><input type="text" data-save="set:name" value="${esc(s.name)}">
    <label class="f">المظهر</label>${chipsHTML([['auto', 'تلقائي'], ['light', 'فاتح'], ['dark', '🌙 ليلي']], s.theme, 'theme')}
    <label class="f">بداية الأسبوع</label>${chipsHTML([[6, 'السبت'], [0, 'الأحد'], [1, 'الاثنين']], s.weekStart, 'weekstart')}</div>
  <h2 class="sec">أهدافي</h2>
  <div class="card">${num('waterGoal', 'أكواب الماء يومياً', s.waterGoal)}${num('engGoal', 'دقائق الإنجليزية يومياً', s.engGoal)}${num('sportGoal', 'أيام النشاط أسبوعياً (مرنة)', s.sportGoal)}${num('engTargetHours', 'ساعات الدراسة المستهدفة للوصول إلى B2', s.engTargetHours)}</div>

  <h2 class="sec">الإشعارات 🔔</h2>
  <div class="card"><div class="row between"><span>إذن الإشعارات: <b>${permTxt}</b></span></div>
    ${perm !== 'granted' && perm !== 'unsupported' && perm !== 'denied' ? '<button class="btn block mt" data-a="askperm">تفعيل الإشعارات</button>' : ''}
    ${perm === 'granted' ? '<button class="btn soft block mt" data-a="testnotif">إرسال إشعار تجريبي الآن</button>' : ''}
    <p class="small muted mt">الإشعارات التي تصل والتطبيق مغلق تماماً تتطلب «الدفع عبر خادم» (القسم التالي). بدونه تصلك التذكيرات عندما يكون التطبيق مفتوحاً أو في الخلفية، وقد يؤجّلها النظام بحسب توفير البطارية.</p></div>
  <div class="card">${rem.map(r => `<div class="li" style="flex-wrap:wrap"><button class="switch ${r.on ? 'on' : ''}" data-a="remtoggle" data-id="${r.id}" role="switch" aria-checked="${r.on}" aria-label="${esc(r.label)}"></button><div class="grow"><b>${esc(r.label)}</b></div><input type="time" value="${r.time}" data-save="rem:${r.id}" aria-label="ساعة ${esc(r.label)}">${r.id.startsWith('c_') ? `<button class="icon-btn" data-a="remdel" data-id="${r.id}">🗑</button>` : ''}</div>`).join('')}
    <button class="btn soft block mt" data-a="remadd">+ تذكير مخصص</button></div>

  <h2 class="sec">إشعارات والتطبيق مغلق (Push)</h2>
  <div class="card"><p class="small muted" style="margin-top:0">تحتاج خادماً صغيراً مجانياً (مجلد <b>server</b> في المشروع، وشرحه في README). إن شغّلتِ التطبيق من نفس الخادم فلا تحتاجين لإدخال العنوان.</p>
    <label class="f">عنوان الخادم (اختياري)</label><input type="url" dir="ltr" data-save="set:server" value="${esc(s.server)}" placeholder="https://your-app.onrender.com">
    <p class="small">الحالة: <b>${sub ? '✅ مرتبط' : 'غير مرتبط'}</b></p>
    ${sub ? '<div class="row gap"><button class="btn soft grow" data-a="pushtest">اختبار</button><button class="btn danger" data-a="pushoff">فصل</button></div>' : '<button class="btn block" data-a="pushon">ربط الإشعارات بالخادم</button>'}</div>

  <h2 class="sec">التثبيت والنسخ الاحتياطي</h2>
  <div class="card">${S.installEvt ? '<button class="btn block mb" data-a="install">📲 تثبيت التطبيق على الهاتف</button>' : '<p class="small muted" style="margin-top:0">للتثبيت: في Chrome اضغطي ⋮ ثم «تثبيت التطبيق» أو «إضافة إلى الشاشة الرئيسية».</p>'}
    <div class="row gap"><button class="btn soft grow" data-a="export">⬇ تصدير نسخة</button><button class="btn soft grow" data-a="import">⬆ استعادة</button></div>
    <input type="file" id="imp" accept="application/json,.json" hidden>
    <button class="btn danger block mt" data-a="reset">حذف كل البيانات</button></div>
  <p class="muted small center">منظم حياتي 🌷 — البيانات محفوظة على جهازك فقط.</p>`;
}

/* ============ الأوراق السفلية (Sheets) ============ */
function taskSheet(id, preset = {}) {
  const t = id ? tasks().find(x => x.id === id) : { cat: preset.cat || 'worship', name: '', points: 10, days: preset.day != null ? [+preset.day] : ALLD, star: false, time: '' };
  if (!t) return;
  S.edit = { id: id || null, days: [...t.days], points: t.points, star: !!t.star, cat: t.cat };
  openSheet(`<h3>${id ? 'تعديل المهمة' : 'مهمة جديدة'}</h3>
   <label class="f">اسم المهمة</label><input type="text" id="t-name" value="${esc(t.name)}" placeholder="مثال: قراءة 10 صفحات">
   <label class="f">المجال</label><select id="t-cat">${CATS.map(c => `<option value="${c.id}" ${c.id === t.cat ? 'selected' : ''}>${c.ic} ${c.name}</option>`).join('')}</select>
   <label class="f">النقاط</label><div class="chips" id="t-pts">${[5, 8, 10, 15, 20].map(p => `<button class="chip ${p === t.points ? 'on' : ''}" data-a="tpts" data-v="${p}">${p}</button>`).join('')}</div>
   <label class="f">أيام التكرار</label><div class="days" id="t-days">${[6, 0, 1, 2, 3, 4, 5].map(d => `<button class="${t.days.includes(d) ? 'on' : ''}" data-a="tday" data-v="${d}">${DAYS_SHORT[d]}</button>`).join('')}</div>
   <label class="f">ساعة (اختياري)</label><input type="time" id="t-time" value="${t.time || ''}">
   <label class="row mt" style="gap:10px"><button class="switch ${t.star ? 'on' : ''}" id="t-star" data-a="tstar" role="switch"></button><span>⭐ أولوية مهمة</span></label>
   <div class="row gap mt"><button class="btn grow" data-a="tsave">حفظ</button>${id ? '<button class="btn danger" data-a="tdelete">حذف</button>' : ''}</div>`);
}
function startSheet() {
  const k = todayKey(), pri = topPriorities(k), rec = dayRec(k) || { done: {} };
  openSheet(`<h3>بدء اليوم ☀️</h3><p class="muted">كيف طاقتك اليوم؟ سنضبط الخطة على قدرك.</p>
  ${chipsHTML([['low', '🌙 خفيفة'], ['mid', '🌿 متوسطة'], ['high', '☀️ عالية']], rec.energy || 'mid', 'energy')}
  <h2 class="sec">أولوياتك</h2><div class="card">${pri.map(t => taskRow(t, k, rec, { noStar: true })).join('') || '<p class="muted">لا مهام</p>'}</div>
  <button class="btn block mt" data-a="startgo">ابدئي بسم الله 🌷</button>`);
}
function reviewSheet() {
  const k = todayKey(), st = dayStats(k), rec = dayRec(k) || {}, rv = rec.review || {}; S.mood = rv.mood || '';
  const msg = st.pct >= 100 ? 'يوم مكتمل، ما شاء الله 🌷' : st.pct >= 60 ? 'يوم جميل ومثمر 🌿' : st.done ? 'خطوات صغيرة تصنع فرقاً 🤍' : 'ليس كل يوم مزدحماً بالإنجاز، وغداً فرصة جديدة 🌙';
  openSheet(`<h3>مراجعة اليوم 🌙</h3><div class="card olive"><div class="row between"><b>${st.pct}%</b><span>${st.done} منجزة · ${st.left} متبقية</span></div><div class="bar mt"><i style="width:${st.pct}%"></i></div><p style="margin-bottom:0">${msg}</p></div>
  <label class="f">كيف كان يومك؟</label><div class="mood">${['😊', '🙂', '😐', '😔'].map(m => `<button class="${S.mood === m ? 'on' : ''}" data-a="mood" data-v="${m}">${m}</button>`).join('')}</div>
  <label class="f">ما الذي أسعدك أو أنجزتِه اليوم؟ وما أريد تذكّره لغدٍ؟</label><textarea id="rv-note">${esc(rv.note || '')}</textarea>
  <div class="row gap mt"><button class="btn grow" data-a="rvsave">حفظ المراجعة</button>${st.left ? '<button class="btn soft" data-a="rvleft">أكمل المتبقي</button>' : ''}</div>`);
}
function flashSheet() {
  const ws = DB.get('words', []).filter(w => !w.learned); const list = ws.length ? ws : DB.get('words', []);
  if (!list.length) return;
  const w = list[S.fc.i % list.length];
  openSheet(`<h3>مراجعة الكلمات 🃏</h3><p class="muted small">${S.fc.i % list.length + 1} / ${list.length} · اضغطي البطاقة لقلبها</p>
  <div class="flash"><div class="fc" data-a="flip" dir="${S.fc.flip ? 'rtl' : 'ltr'}">${S.fc.flip ? esc(w.m) + (w.ex ? `<div class="small muted" dir="ltr" style="margin-top:10px;font-family:var(--font)">${esc(w.ex)}</div>` : '') : esc(w.w)}</div></div>
  <div class="row gap mt"><button class="btn soft grow" data-a="fcnext">أعيدها لاحقاً</button><button class="btn grow" data-a="fcknow" data-id="${w.id}">عرفتها ✓</button></div>`);
}
function exSheet() {
  openSheet(`<h3>تسجيل تمرين 💪</h3><label class="f">النوع</label><select id="ex-t">${['مشي سريع', 'تمارين قوة', 'كارديو', 'يوغا / تمدد', 'سباحة', 'رياضة مع ابني', 'أخرى'].map(x => `<option>${x}</option>`).join('')}</select>
  <label class="f">المدة (دقائق)</label><input type="number" inputmode="numeric" id="ex-m" value="20" min="1"><button class="btn block mt" data-a="exsave">حفظ</button>`);
}
function remSheet() {
  openSheet(`<h3>تذكير جديد 🔔</h3><label class="f">الاسم</label><input type="text" id="r-l" placeholder="مثال: شرب الماء"><label class="f">الساعة</label><input type="time" id="r-t" value="10:00"><label class="f">نص الإشعار</label><input type="text" id="r-b" placeholder="رسالة لطيفة"><button class="btn block mt" data-a="remsave">حفظ</button>`);
}

/* ============ توجيه وعرض ============ */
const ROUTES = { '/': vHome, '/tasks': vTasks, '/calendar': vCalendar, '/progress': vProgress, '/more': vMore, '/english': vEnglish, '/health': vHealth, '/care': vCare, '/settings': vSettings };
const routePath = () => location.hash.replace(/^#/, '') || '/';
const NAV = [['/', '🏠', 'الرئيسية'], ['/tasks', '✅', 'المهام'], ['/calendar', '📅', 'التقويم'], ['/progress', '🌷', 'إنجازاتي'], ['/more', '☰', 'المزيد']];
function render(keepScroll = true) {
  const y = window.scrollY, r = routePath(), f = ROUTES[r] || vHome;
  $('#view').innerHTML = f();
  const sub = ['/english', '/health', '/care', '/settings'].includes(r) ? '/more' : r;
  $('#nav').innerHTML = NAV.map(([h, i, l]) => `<a href="#${h}" class="${h === sub ? 'on' : ''}" ${h === sub ? 'aria-current="page"' : ''}><span class="ic">${i}</span>${l}</a>`).join('');
  window.scrollTo(0, keepScroll ? y : 0);
  if (r === '/english') tickTimer();
}
let timerI;
function tickTimer() {
  clearInterval(timerI); const tm = DB.get('engTimer'); if (!tm) return;
  const up = () => { const el = $('#etimer'); if (!el) return clearInterval(timerI); const s = Math.floor((Date.now() - tm.start) / 1000); el.textContent = `${pad(Math.floor(s / 60))}:${pad(s % 60)}`; };
  up(); timerI = setInterval(up, 1000);
}

/* ============ الأفعال ============ */
const A = {
  async toggle(el) {
    const k = el.dataset.k, on = await toggleTask(k, el.dataset.id);
    await checkAch(); render();
    if (on) { const st = dayStats(k); if (st.pct === 100 && st.total > 1) toast('ما شاء الله! أنجزتِ كل مهام اليوم 🌷'); if (navigator.vibrate) navigator.vibrate(15); }
  },
  async star(el) { const ts = tasks(); const t = ts.find(x => x.id === el.dataset.id); t.star = !t.star; await DB.set('tasks', ts); render(); },
  edit(el) { taskSheet(el.dataset.id); },
  addtask(el) { taskSheet(null, { cat: el.dataset.cat, day: el.dataset.day }); },
  collapse(el) { S.collapsed[el.dataset.id] = !S.collapsed[el.dataset.id]; render(); },
  filter(el) { S.filter = el.dataset.v; render(); },
  day(el) { S.viewDate = addDays(S.viewDate, +el.dataset.v); render(); },
  daytoday() { S.viewDate = todayKey(); render(); },
  closesheet: closeSheet,
  // ورقة المهمة
  tpts(el) { S.edit.points = +el.dataset.v; $$('#t-pts .chip').forEach(c => c.classList.toggle('on', c === el)); },
  tday(el) { const v = +el.dataset.v, d = S.edit.days; const i = d.indexOf(v); i >= 0 ? d.splice(i, 1) : d.push(v); el.classList.toggle('on'); },
  tstar(el) { S.edit.star = !S.edit.star; el.classList.toggle('on'); },
  async tsave() {
    const name = $('#t-name').value.trim(); if (!name) return toast('اكتبي اسم المهمة');
    if (!S.edit.days.length) return toast('اختاري يوماً واحداً على الأقل');
    const ts = tasks(), data = { name, cat: $('#t-cat').value, points: S.edit.points, days: [...S.edit.days].sort(), star: S.edit.star, time: $('#t-time').value };
    if (S.edit.id) Object.assign(ts.find(x => x.id === S.edit.id), data); else ts.push({ id: 't_' + uid(), auto: '', slot: '', ...data });
    await DB.set('tasks', ts); closeSheet(); render(); toast('تم الحفظ ✅');
  },
  async tdelete() { if (!confirm('حذف هذه المهمة؟ (سجل إنجازاتك السابقة يبقى كما هو)')) return; await DB.set('tasks', tasks().filter(x => x.id !== S.edit.id)); closeSheet(); render(); toast('تم الحذف'); },
  // الرئيسية
  startday: startSheet, reviewday: reviewSheet,
  async energy(el) { await saveDay(todayKey(), r => { r.energy = el.dataset.v; }); $$('#sheet-root .chip').forEach(c => c.classList.toggle('on', c === el)); },
  async startgo() { const r = dayRec(todayKey()) || {}; await saveDay(todayKey(), x => { x.started = Date.now(); }); S.filter = r.energy === 'low' ? 'ess' : 'all'; S.viewDate = todayKey(); closeSheet(); location.hash = '#/tasks'; toast('بسم الله، يوم موفق 🌷'); },
  mood(el) { S.mood = el.dataset.v; $$('.mood button').forEach(b => b.classList.toggle('on', b === el)); },
  async rvsave() { await saveDay(todayKey(), r => { r.review = { mood: S.mood, note: $('#rv-note').value.trim(), at: Date.now() }; }); closeSheet(); render(); toast('تم حفظ المراجعة 🤍'); },
  rvleft() { closeSheet(); S.filter = 'left'; S.viewDate = todayKey(); location.hash = '#/tasks'; render(); },
  // الماء
  async 'water+'() { await setWater((+(dayRec(todayKey()) || {}).water || 0) + 1); },
  async glass(el) { const v = +el.dataset.v, cur = +(dayRec(todayKey()) || {}).water || 0; await setWater(cur === v ? v - 1 : v); },
  // التقويم
  month(el) { const [y, m] = S.calMonth.split('-').map(Number), d = new Date(y, m - 1 + (+el.dataset.v), 1); S.calMonth = `${d.getFullYear()}-${pad(d.getMonth() + 1)}`; S.calSel = S.calMonth === todayKey().slice(0, 7) ? todayKey() : S.calMonth + '-01'; render(); },
  calsel(el) { S.calSel = el.dataset.k; render(); },
  openday(el) { S.viewDate = el.dataset.k; S.filter = 'all'; location.hash = '#/tasks'; },
  // الإنجازات
  mrmonth(el) { const [y, m] = S.mrMonth.split('-').map(Number), d = new Date(y, m - 1 + (+el.dataset.v), 1); S.mrMonth = `${d.getFullYear()}-${pad(d.getMonth() + 1)}`; render(); },
  async mrate(el) { const o = DB.get('mr:' + S.mrMonth) || { r: {} }; o.r = o.r || {}; o.r[el.dataset.c] = +el.dataset.v; await DB.set('mr:' + S.mrMonth, o); render(); },
  // الإنجليزية
  skill(el) { S.skill = el.dataset.v; render(); },
  async engadd(el) { await addEng(S.skill || 'vocab', +el.dataset.v); render(); },
  async 'etimer-start'() { await DB.set('engTimer', { start: Date.now(), skill: S.skill || 'listening' }); render(); },
  async 'etimer-stop'() { const tm = DB.get('engTimer'); clearInterval(timerI); await DB.del('engTimer'); const m = Math.max(1, Math.round((Date.now() - tm.start) / 60000)); await addEng(tm.skill, m); toast(`تم تسجيل ${m} دقيقة 📖`); render(); },
  async erate(el) { const e = DB.get('eng'); e.ratings = e.ratings || {}; e.ratings[el.dataset.c] = +el.dataset.v; await DB.set('eng', e); render(); },
  async addword() {
    const w = $('#w-w').value.trim(), m = $('#w-m').value.trim(); if (!w || !m) return toast('اكتبي الكلمة ومعناها');
    const ws = DB.get('words', []); ws.push({ id: uid(), w, m, ex: $('#w-e').value.trim(), date: todayKey(), learned: false }); await DB.set('words', ws);
    await syncAuto(todayKey()); await checkAch(); render(); toast('أُضيفت الكلمة 🔤');
  },
  async wlearn(el) { const ws = DB.get('words', []); const w = ws.find(x => x.id === el.dataset.id); w.learned = !w.learned; await DB.set('words', ws); render(); },
  async wdel(el) { if (!confirm('حذف الكلمة؟')) return; await DB.set('words', DB.get('words', []).filter(x => x.id !== el.dataset.id)); await syncAuto(todayKey()); render(); },
  flash() { S.fc = { i: 0, flip: false }; flashSheet(); }, flip() { S.fc.flip = !S.fc.flip; flashSheet(); },
  fcnext() { S.fc = { i: S.fc.i + 1, flip: false }; flashSheet(); },
  async fcknow(el) { const ws = DB.get('words', []); ws.find(x => x.id === el.dataset.id).learned = true; await DB.set('words', ws); S.fc = { i: S.fc.i, flip: false }; if (!ws.some(w => !w.learned)) { closeSheet(); render(); toast('راجعتِ كل كلماتك 🌷'); } else flashSheet(); },
  // التغذية والرياضة
  async suggest(el) { const m = el.dataset.m, txt = SUGGEST[m][+el.dataset.i]; await saveDay(todayKey(), r => { r.meals = r.meals || {}; r.meals[m] = r.meals[m] ? r.meals[m] + '، ' + txt : txt; }); render(); },
  exadd: exSheet,
  async exsave() { await saveDay(todayKey(), r => { r.ex = r.ex || []; r.ex.push({ t: $('#ex-t').value, m: +$('#ex-m').value || 0 }); }); await checkAch(); closeSheet(); render(); toast('أحسنتِ 💪'); },
  async exdel(el) { await saveDay(todayKey(), r => { r.ex.splice(+el.dataset.i, 1); }); render(); },
  // العناية
  async prod(el) { const s = el.dataset.s, id = el.dataset.id; await saveDay(todayKey(), r => { r.skin = r.skin || { am: [], pm: [] }; const a = r.skin[s] = r.skin[s] || []; const i = a.indexOf(id); i >= 0 ? a.splice(i, 1) : a.push(id); }); render(); },
  async prodadd() { const n = $('#np-n').value.trim(); if (!n) return toast('اكتبي اسم المنتج'); const p = DB.get('products', []); p.push({ id: uid(), name: n, slot: $('#np-s').value }); await DB.set('products', p); render(); },
  async proddel(el) { await DB.set('products', DB.get('products', []).filter(p => p.id !== el.dataset.id)); render(); },
  // الإعدادات
  async theme(el) { await setSetting('theme', el.dataset.v); applyTheme(); render(); },
  async weekstart(el) { await setSetting('weekStart', +el.dataset.v); render(); },
  async askperm() { const p = await Notif.ask(); render(); toast(p === 'granted' ? 'تم تفعيل الإشعارات 🔔' : 'لم يُمنح الإذن'); },
  async testnotif() { try { await Notif.show('منظم حياتي 🌷', 'هذا إشعار تجريبي حقيقي من هاتفك.', 'test'); } catch { toast('تعذّر إرسال الإشعار'); } },
  async remtoggle(el) {
    const rs = DB.get('reminders', []), r = rs.find(x => x.id === el.dataset.id);
    if (!r.on && Notif.perm() !== 'granted') { const p = await Notif.ask(); if (p !== 'granted') { toast('فعّلي إذن الإشعارات أولاً'); return render(); } }
    r.on = !r.on; await DB.set('reminders', rs); await Push.sync(); render();
  },
  async remdel(el) { await DB.set('reminders', DB.get('reminders', []).filter(r => r.id !== el.dataset.id)); await Push.sync(); render(); },
  remadd: remSheet,
  async remsave() { const l = $('#r-l').value.trim(); if (!l) return toast('اكتبي اسم التذكير'); const rs = DB.get('reminders', []); rs.push({ id: 'c_' + uid(), label: l, time: $('#r-t').value || '10:00', on: false, body: $('#r-b').value.trim() || l + ' 🌷' }); await DB.set('reminders', rs); closeSheet(); render(); toast('أُضيف التذكير — فعّليه من المفتاح'); },
  async pushon() {
    try {
      if (Notif.perm() !== 'granted') { const p = await Notif.ask(); if (p !== 'granted') return toast('فعّلي إذن الإشعارات أولاً'); }
      if (!(await Push.available())) return toast('الخادم غير متاح. راجعي عنوان الخادم');
      await Push.subscribe(); toast('تم الربط ✅ ستصلك الإشعارات حتى والتطبيق مغلق'); render();
    } catch (e) { toast('تعذّر الربط: ' + (e.message || '')); }
  },
  async pushoff() { await Push.unsubscribe(); render(); toast('تم الفصل'); },
  async pushtest() { try { await Push.test(); toast('أُرسل إشعار تجريبي'); } catch (e) { toast(e.message); } },
  async install() { if (!S.installEvt) return; S.installEvt.prompt(); await S.installEvt.userChoice; S.installEvt = null; render(); },
  export() { exportBackup(); toast('تم تنزيل النسخة الاحتياطية'); },
  import() { $('#imp').click(); },
  async reset() { if (!confirm('سيتم حذف كل بياناتك نهائياً. هل أنتِ متأكدة؟')) return; if (!confirm('تأكيد أخير: حذف كل شيء؟')) return; await Push.unsubscribe(); await DB.clearAll(); await seed(); S.viewDate = todayKey(); render(); toast('تمت إعادة الضبط'); },
};
async function setSetting(k, v) { const s = settings(); s[k] = v; await DB.set('settings', s); }
async function setWater(n) { await saveDay(todayKey(), r => { r.water = Math.max(0, n); }); await syncAuto(todayKey()); await checkAch(); render(); }
async function addEng(skill, min) { await saveDay(todayKey(), r => { r.eng = r.eng || {}; r.eng[skill] = (+r.eng[skill] || 0) + min; }); await checkAch(); }

/* حفظ الحقول النصية تلقائياً */
async function saveField(path, val) {
  const k = todayKey(); const [t, sub] = path.split(':');
  if (t === 'meal') await saveDay(k, r => { r.meals = r.meals || {}; r.meals[sub] = val; });
  else if (t === 'nnote') await saveDay(k, r => { r.nnote = val; });
  else if (t === 'skinnote') await saveDay(k, r => { r.skinnote = val; });
  else if (t === 'walk') { await saveDay(k, r => { r.walk = Math.max(0, +val || 0); }); await checkAch(); }
  else if (t === 'plan') { const p = DB.get('plan', {}); p[sub] = val; await DB.set('plan', p); }
  else if (t === 'engrev') { const e = DB.get('eng'); e.reviews = e.reviews || {}; e.reviews[weekStartKey(k)] = val; await DB.set('eng', e); }
  else if (t === 'mr') { const o = DB.get('mr:' + S.mrMonth) || { r: {} }; o[sub] = val; await DB.set('mr:' + S.mrMonth, o); }
  else if (t === 'set') { const num = ['waterGoal', 'engGoal', 'sportGoal', 'engTargetHours'].includes(sub); await setSetting(sub, num ? Math.max(1, +val || 1) : val); if (sub === 'name') return; }
  else if (t === 'rem') { const rs = DB.get('reminders', []); const r = rs.find(x => x.id === sub); if (r && /^\d\d:\d\d$/.test(val)) { r.time = val; await DB.set('reminders', rs); await Push.sync(); } }
}
const debounces = {};
document.addEventListener('click', e => { const el = e.target.closest('[data-a]'); if (!el) return; const f = A[el.dataset.a]; if (f) { e.preventDefault(); f(el, e); } });
document.addEventListener('input', e => {
  const p = e.target.dataset && e.target.dataset.save; if (!p || e.target.type === 'time' || e.target.type === 'number') return;
  clearTimeout(debounces[p]); debounces[p] = setTimeout(() => saveField(p, e.target.value), 500);
});
document.addEventListener('change', async e => {
  const t = e.target;
  if (t.id === 'imp' && t.files[0]) { try { await importBackup(t.files[0]); applyTheme(); render(); toast('تمت استعادة بياناتك ✅'); } catch (er) { toast('تعذّرت الاستعادة: ' + er.message); } t.value = ''; return; }
  const p = t.dataset && t.dataset.save; if (!p) return;
  clearTimeout(debounces[p]); await saveField(p, t.value);
  if (p === 'walk' || p.startsWith('set:') && p !== 'set:name' && p !== 'set:server') render();
});
