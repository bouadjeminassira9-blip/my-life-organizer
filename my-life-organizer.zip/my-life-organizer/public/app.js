'use strict';
(async function boot() {
  await DB.load();
  await seed();
  applyTheme();
  matchMedia('(prefers-color-scheme:dark)').addEventListener?.('change', applyTheme);

  // تسجيل Service Worker
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
    try { await navigator.serviceWorker.register('sw.js'); } catch (e) { console.warn('SW', e); }
    navigator.serviceWorker.addEventListener('message', e => { if (e.data && e.data.type === 'goto') location.hash = e.data.hash; });
  }

  window.addEventListener('hashchange', () => { closeSheet(); render(false); });
  window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); S.installEvt = e; if (routePath() === '/settings') render(); });
  window.addEventListener('appinstalled', () => { S.installEvt = null; toast('تم تثبيت التطبيق 🌷'); });
  render(false);

  // الساعة الحية
  setInterval(() => { const c = $('#clock'); if (c) c.textContent = clockStr(); }, 1000);

  // تغيّر اليوم (بعد منتصف الليل) أو العودة للتطبيق
  const rollover = () => {
    const t = todayKey();
    if (t !== S.today) { if (S.viewDate === S.today) S.viewDate = t; S.today = t; render(false); }
    Notif.check();
  };
  document.addEventListener('visibilitychange', () => { if (!document.hidden) rollover(); });
  setInterval(rollover, 30000);
  Notif.check();
  if (Notif.perm() === 'granted') Notif.registerPeriodic();
  if (DB.get('pushSub')) Push.sync();

  // مزامنة إنجاز الماء/الكلمات التلقائي عند الفتح
  await syncAuto(todayKey()); render();
})();
