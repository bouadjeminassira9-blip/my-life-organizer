'use strict';
const VERSION = 'lo-v1';
const SHELL = ['./', 'index.html', 'styles.css', 'core.js', 'views.js', 'app.js', 'manifest.webmanifest', 'icons/icon-192.png', 'icons/icon-512.png', 'icons/maskable-512.png', 'icons/apple-touch-icon.png'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSION).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});

// استراتيجية: stale-while-revalidate للملفات، والشبكة أولاً للتنقل
self.addEventListener('fetch', e => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== 'GET' || url.pathname.startsWith('/api/')) return;
  if (req.mode === 'navigate') {
    e.respondWith(fetch(req).then(r => { const cp = r.clone(); caches.open(VERSION).then(c => c.put('index.html', cp)); return r; }).catch(() => caches.match('index.html')));
    return;
  }
  const isFont = url.hostname.includes('fonts.googleapis.com') || url.hostname.includes('fonts.gstatic.com');
  if (url.origin !== location.origin && !isFont) return;
  e.respondWith(caches.open(VERSION).then(async c => {
    const hit = await c.match(req);
    const net = fetch(req).then(r => { if (r && (r.ok || r.type === 'opaque')) c.put(req, r.clone()); return r; }).catch(() => hit);
    return hit || net;
  }));
});

/* ---- قراءة البيانات من IndexedDB داخل الـ SW ---- */
function idb() { return new Promise((res, rej) => { const r = indexedDB.open('life-organizer', 1); r.onupgradeneeded = () => r.result.createObjectStore('kv'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); }); }
const idbGet = (db, k) => new Promise(res => { const r = db.transaction('kv').objectStore('kv').get(k); r.onsuccess = () => res(r.result); r.onerror = () => res(undefined); });
const idbPut = (db, k, v) => new Promise(res => { const tx = db.transaction('kv', 'readwrite'); tx.objectStore('kv').put(v, k); tx.oncomplete = res; tx.onerror = res; });
const pad = n => String(n).padStart(2, '0');
const keyOf = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

async function checkReminders() {
  let db; try { db = await idb(); } catch { return; }
  if (await idbGet(db, 'pushSub')) return; // الخادم يتولى الإرسال
  const rem = (await idbGet(db, 'reminders')) || [], st = (await idbGet(db, 'notifState')) || {};
  const now = new Date(), nowMin = now.getHours() * 60 + now.getMinutes(), today = keyOf(now);
  let changed = false;
  for (const r of rem) {
    if (!r.on || !/^\d\d:\d\d$/.test(r.time)) continue;
    const [h, m] = r.time.split(':').map(Number), diff = nowMin - (h * 60 + m);
    if (diff >= 0 && diff <= 120 && st[r.id] !== today) {
      st[r.id] = today; changed = true;
      await self.registration.showNotification('منظم حياتي 🌷', { body: r.body, tag: r.id + '-' + today, icon: 'icons/icon-192.png', badge: 'icons/icon-192.png', lang: 'ar', dir: 'rtl', data: { url: './index.html#/tasks' } });
    }
  }
  if (changed) await idbPut(db, 'notifState', st);
}
self.addEventListener('periodicsync', e => { if (e.tag === 'check-reminders') e.waitUntil(checkReminders()); });

/* ---- إشعارات Push القادمة من الخادم ---- */
self.addEventListener('push', e => {
  let d = {}; try { d = e.data ? e.data.json() : {}; } catch { d = { body: e.data && e.data.text() }; }
  e.waitUntil(self.registration.showNotification(d.title || 'منظم حياتي 🌷', {
    body: d.body || '', tag: d.tag || 'lo', icon: 'icons/icon-192.png', badge: 'icons/icon-192.png', lang: 'ar', dir: 'rtl', vibrate: [120, 60, 120], data: { url: d.url || './index.html#/tasks' },
  }));
});
self.addEventListener('notificationclick', e => {
  e.notification.close();
  const url = (e.notification.data && e.notification.data.url) || './index.html';
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(list => {
    for (const c of list) if ('focus' in c) { c.postMessage({ type: 'goto', hash: new URL(url, self.location.href).hash || '#/tasks' }); return c.focus(); }
    return self.clients.openWindow(url);
  }));
});
